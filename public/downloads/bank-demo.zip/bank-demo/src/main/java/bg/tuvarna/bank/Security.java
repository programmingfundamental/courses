package bg.tuvarna.bank;

import javax.sql.DataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
class Security {
    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    UserDetailsService users(DataSource ds) {
        var users = new JdbcUserDetailsManager(ds);
        users.setUsersByUsernameQuery("select login, password_hash, true from bank_users where login = ?");
        users.setAuthoritiesByUsernameQuery("select login, 'ROLE_USER' from bank_users where login = ?");
        return users;
    }

    @Bean
    SecurityFilterChain filter(HttpSecurity http) throws Exception {
        return http
            .authorizeHttpRequests(r -> r
                .requestMatchers("/", "/login", "/bank.css", "/error").permitAll()
                .anyRequest().authenticated())
            .formLogin(f -> f.loginPage("/login").loginProcessingUrl("/login")
                .defaultSuccessUrl("/accounts", true).failureUrl("/login?error").permitAll())
            .logout(l -> l.logoutSuccessUrl("/login?logout"))
            // Inline scripts intentionally execute for the stored-XSS classroom demonstration.
            .headers(h -> h.contentSecurityPolicy(c -> c.policyDirectives(
                "default-src 'none'; script-src 'unsafe-inline'; style-src 'self'; img-src 'self' data:; "
                + "form-action 'self'; frame-ancestors 'none'; base-uri 'none'")))
            .build();
    }
}
